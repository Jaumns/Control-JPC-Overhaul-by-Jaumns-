# ==========================================
# CONFIGURAÇÃO DE CAMINHOS AUTOMÁTICA
# ==========================================
# Agora o script usa a pasta ONDE ELE ESTÁ SALVO como origem
$diretorioBase = $PSScriptRoot

if ([string]::IsNullOrEmpty($diretorioBase)) {
    $diretorioBase = "C:\Users\Jaumns\Downloads\Default-Generic-User"
}

$pastaSaidaSteam = Join-Path $diretorioBase "STEAM_SAVES_CONVERTED"
$pastaSaidaNoDRM = Join-Path $diretorioBase "NO_DRM_SAVES_CONVERTED"

Write-Host "Executando conversor na pasta: $diretorioBase`n" -ForegroundColor White

# ==========================================
# MODO 1: CONVERTER NO DRM -> STEAM
# ==========================================
$arquivosChunk = Get-ChildItem -Path $diretorioBase -Filter *.chunk -Recurse | Where-Object { 
    $_.DirectoryName -notmatch "CONVERTED" -and $_.DirectoryName -ne $pastaSaidaNoDRM 
}

if ($arquivosChunk) {
    Write-Host "[DETECTADO] Arquivos .chunk encontrados. Convertendo para padrão STEAM..." -ForegroundColor Cyan
    if (-not (Test-Path -Path $pastaSaidaSteam)) { New-Item -ItemType Directory -Path $pastaSaidaSteam | Out-Null }

    foreach ($arquivo in $arquivosChunk) {
        $nomePasta = $arquivo.Directory.Name
        $nomeBase = $arquivo.BaseName
        if ($nomePasta -match '\d+') {
            $numeroSlot = [int]$matches[0]
            $slotFormatado = $numeroSlot.ToString("00")
            $novoNome = "savegame-slot-${slotFormatado}_${nomeBase}"
            Copy-Item -Path $arquivo.FullName -Destination "$pastaSaidaSteam\$novoNome" -Force
            Write-Host "-> Criado Steam Save: $novoNome" -ForegroundColor Green
        }
    }
}

# ==========================================
# MODO 2: CONVERTER STEAM -> NO DRM
# ==========================================
$arquivosSteam = Get-ChildItem -Path $diretorioBase -Recurse | Where-Object {
    $_.Name -like "savegame-slot-*" -and $_.Extension -ne ".chunk" -and $_.DirectoryName -notmatch "CONVERTED" -and -not $_.PSIsContainer
}

if ($arquivosSteam) {
    Write-Host "`n[DETECTADO] Arquivos unificados padrão Steam encontrados. Convertendo para NO DRM..." -ForegroundColor Cyan
    foreach ($arquivo in $arquivosSteam) {
        if ($arquivo.Name -match 'savegame-slot-(\d+)_(.+)') {
            $slotNum = $matches[1]
            $nomeReal = $matches[2]
            $pastaSlotDestino = Join-Path $pastaSaidaNoDRM "savegame-slot-$slotNum"
            if (-not (Test-Path -Path $pastaSlotDestino)) { New-Item -ItemType Directory -Path $pastaSlotDestino | Out-Null }
            $nomeArquivoNoDRM = "${nomeReal}.chunk"
            $caminhoFinal = Join-Path $pastaSlotDestino $nomeArquivoNoDRM
            Copy-Item -Path $arquivo.FullName -Destination $caminhoFinal -Force
            Write-Host "-> Reconstruído: ...\savegame-slot-$slotNum\$nomeArquivoNoDRM" -ForegroundColor Green
        }
    }
}

if (-not $arquivosChunk -and -not $arquivosSteam) {
    Write-Host "Nenhum arquivo compatível para conversão foi encontrado em $diretorioBase" -ForegroundColor Yellow
}

# ==========================================
# TRAVA PARA A JANELA NÃO FECHAR
# ==========================================
Write-Host "`n==========================================" -ForegroundColor White
Read-Host "Processo concluído! Pressione ENTER para fechar"